package com.jarvis.clap

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Tela única: chave do Gemini, modelo, interruptores, sensibilidade e iniciar/parar. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var claps: Switch
    private lateinit var voice: Switch
    private lateinit var sens: SeekBar

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            status.text = i?.getStringExtra(JarvisService.EXTRA_TEXT).orEmpty()
        }
    }

    private fun tv(t: String, size: Float = 14f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 24, 0, 8) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences(JarvisService.PREFS, MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }

        root.addView(tv("Jarvis", 28f))
        root.addView(tv("Ativação por duas palmas ou \"Hey Jarvis\". Só conversa: não controla o celular."))

        root.addView(tv("Chave do Gemini (grátis em aistudio.google.com)"))
        key = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(p.getString("apiKey", ""))
        }
        root.addView(key)

        root.addView(tv("Modelo do Gemini"))
        model = EditText(this).apply { setText(p.getString("model", "gemini-flash-latest")) }
        root.addView(model)

        claps = Switch(this).apply { text = "Ativar por duas palmas"; isChecked = p.getBoolean("claps", true) }
        voice = Switch(this).apply { text = "Ativar por \"Hey Jarvis\" (offline)"; isChecked = p.getBoolean("voice", true) }
        root.addView(claps); root.addView(voice)

        root.addView(tv("Sensibilidade das palmas (direita = mais sensível)"))
        sens = SeekBar(this).apply {
            max = 100
            val lvl = p.getFloat("minLevel", 0.05f)
            progress = (((0.15f - lvl) / 0.13f) * 100f).toInt().coerceIn(0, 100)
        }
        root.addView(sens)

        val start = Button(this).apply { text = "Iniciar"; setOnClickListener { save(); ensurePermsThenStart() } }
        val stop = Button(this).apply {
            text = "Parar"
            setOnClickListener { startService(Intent(this@MainActivity, JarvisService::class.java).setAction(JarvisService.ACTION_STOP)) }
        }
        root.addView(start); root.addView(stop)

        status = tv("Parado")
        root.addView(status)
        root.addView(tv("Privacidade: palmas e \"Jarvis\" são detectados no aparelho, sem enviar áudio. " +
            "O que você diz depois é transcrito pelo reconhecimento de voz do sistema (pode usar a nuvem do Google), " +
            "e só o TEXTO vai ao Gemini."))

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun save() {
        val lvl = 0.15f - 0.13f * (sens.progress / 100f)
        getSharedPreferences(JarvisService.PREFS, MODE_PRIVATE).edit()
            .putString("apiKey", key.text.toString().trim())
            .putString("model", model.text.toString().trim())
            .putBoolean("claps", claps.isChecked)
            .putBoolean("voice", voice.isChecked)
            .putFloat("minLevel", lvl)
            .apply()
    }

    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) startJarvis() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startJarvis()
        else status.text = "Sem permissão de microfone, não consigo ouvir."
    }

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_START))
        status.text = "Iniciando…"
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(JarvisService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, f)
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }
}
