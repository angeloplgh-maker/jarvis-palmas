package com.jarvis.clap

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Cliente mínimo da API do Gemini (chave gratuita do Google AI Studio). Só envia TEXTO. */
object Gemini {
    private const val SYSTEM =
        "Você é o JARVIS, um assistente por voz. Responda em português do Brasil, " +
        "em no máximo duas frases curtas, sem markdown, sem listas e sem emojis. " +
        "Você só conversa: não consegue controlar o celular nem executar ações. " +
        "Se não souber algo, diga que não sabe."

    private fun msg(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    @Throws(IOException::class)
    fun ask(key: String, model: String, history: List<Pair<String, String>>, user: String): String {
        val contents = JSONArray()
        for ((u, m) in history.takeLast(6)) {
            contents.put(msg("user", u))
            contents.put(msg("model", m))
        }
        contents.put(msg("user", user))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val m = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault("erro HTTP $code")
                throw IOException(m.take(140))
            }
            val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (k in 0 until parts.length()) sb.append(parts.getJSONObject(k).optString("text"))
            val out = sb.toString().trim()
            if (out.isEmpty()) throw IOException("resposta vazia")
            return out
        } finally {
            c.disconnect()
        }
    }
}
