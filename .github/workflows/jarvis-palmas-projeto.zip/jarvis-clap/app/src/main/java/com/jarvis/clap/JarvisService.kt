package com.jarvis.clap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Serviço em primeiro plano (tipo microfone) que:
 *  1. ouve o microfone com UM único AudioRecord;
 *  2. alimenta o ClapDetector (duas palmas) e o Vosk (palavra "Jarvis", offline);
 *  3. ao ser ativado, SOLTA o microfone, fala "Sim?", escuta o comando (SpeechRecognizer do sistema),
 *     manda o texto ao Gemini e fala a resposta; depois volta a ouvir.
 * Como o microfone é solto durante a conversa, o Jarvis não se ativa com a própria voz.
 */
class JarvisService : Service() {

    companion object {
        const val ACTION_START = "com.jarvis.clap.START"
        const val ACTION_STOP = "com.jarvis.clap.STOP"
        const val ACTION_STATUS = "com.jarvis.clap.STATUS"
        const val EXTRA_TEXT = "text"
        const val PREFS = "jarvis"
        private const val CHANNEL = "jarvis_listen"
        private const val NOTIF_ID = 1
        private val WAKE_WORDS = listOf("jarvis", "jarvas", "garvis", "charvis", "travis", "jar vis")
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ttsDone = HashMap<String, () -> Unit>()
    private var model: Model? = null
    private var speechRec: SpeechRecognizer? = null
    private val history = mutableListOf<Pair<String, String>>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY
        running = true
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        goForeground("Iniciando…")
        initTts()
        if (prefs.getBoolean("voice", true)) {
            status("Carregando modelo de voz…")
            StorageService.unpack(this, "model-en-us", "model",
                { m: Model -> model = m; beginListening() },
                { e: java.io.IOException ->
                    status("Erro no modelo de voz: ${e.message}")
                    beginListening() // continua só com as palmas
                })
        } else {
            beginListening()
        }
        return START_STICKY
    }

    // ---------- notificação / status ----------

    private fun goForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis ouvindo", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, n)
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Parar", stop).build())
            .build()
    }

    private fun status(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_TEXT, text))
    }

    // ---------- voz de saída ----------

    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                val r = t.setLanguage(Locale("pt", "BR"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { finish(id) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { finish(id) }
                    private fun finish(id: String?) {
                        val cb = if (id == null) null else synchronized(ttsDone) { ttsDone.remove(id) }
                        if (cb != null) main.post { cb() }
                    }
                })
                ttsReady = true
            } else status("Falha ao iniciar a voz (TTS)")
        }
    }

    private fun speak(text: String, then: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) { then(); return }
        val id = "u" + System.nanoTime()
        synchronized(ttsDone) { ttsDone[id] = then }
        t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    // ---------- ouvir (palmas + "Jarvis") ----------

    private fun beginListening() {
        if (!running) return
        thread(name = "jarvis-listen") { listenLoop() }
    }

    private fun levelFromPrefs(): Float = prefs.getFloat("minLevel", 0.05f)

    private fun listenLoop() {
        val clapsOn = prefs.getBoolean("claps", true)
        val m = model
        val voiceOn = prefs.getBoolean("voice", true) && m != null
        if (!clapsOn && !voiceOn) { status("Nada ativado: ligue palmas ou voz"); return }

        val sr = 16000
        val chunk = 1280 // 80 ms = 4 quadros de 20 ms
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, chunk * 4))
        } catch (e: Exception) { null }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            status("Microfone indisponível. Tentando de novo…")
            rec?.release()
            retryLater()
            return
        }
        val clap = ClapDetector(levelFromPrefs())
        val vosk = if (voiceOn && m != null) Recognizer(m, sr.toFloat()) else null
        val data = ShortArray(chunk)
        var trigger: String? = null
        var micError = false
        status(listOfNotNull(if (clapsOn) "duas palmas" else null, if (voiceOn) "\"Hey Jarvis\"" else null)
            .joinToString(" ou ") + " — ouvindo")
        try {
            rec.startRecording()
            while (running && trigger == null) {
                var n = 0
                while (n < chunk) {
                    val r = rec.read(data, n, chunk - n)
                    if (r <= 0) { micError = true; break }
                    n += r
                }
                if (micError) break
                if (clapsOn) {
                    var f = 0
                    while (f < chunk) {
                        if (clap.process(data, f)) { trigger = "palmas"; break }
                        f += ClapDetector.FRAME
                    }
                }
                if (trigger == null && vosk != null) {
                    val txt = if (vosk.acceptWaveForm(data, chunk)) vosk.result else vosk.partialResult
                    if (isWake(txt)) trigger = "voz"
                }
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            vosk?.close()
        }
        if (!running) return
        if (trigger != null) main.post { onTriggered(trigger) }
        else if (micError) { status("Microfone ocupado. Tentando de novo…"); retryLater() }
    }

    private fun isWake(json: String): Boolean {
        val t = try {
            val o = JSONObject(json)
            (o.optString("text") + " " + o.optString("partial")).lowercase()
        } catch (_: Exception) { return false }
        return WAKE_WORDS.any { t.contains(it) }
    }

    private fun retryLater() { main.postDelayed({ beginListening() }, 3000) }
    private fun resume() { main.postDelayed({ if (running) beginListening() }, 400) }

    // ---------- conversa ----------

    private fun onTriggered(source: String) {
        if (!running) return
        status("Ativado por $source")
        speak("Sim?") { listenCommand() }
    }

    private fun listenCommand() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("O reconhecimento de voz do sistema não está disponível.") { resume() }
            return
        }
        status("Estou ouvindo você…")
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        speechRec = sr
        val guard = Runnable { cleanupRec(); resume() }
        main.postDelayed(guard, 15000)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                main.removeCallbacks(guard)
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                cleanupRec()
                if (text.isNullOrBlank()) resume() else answer(text)
            }
            override fun onError(error: Int) {
                main.removeCallbacks(guard)
                cleanupRec()
                resume() // sem fala / sem entendimento: volta a ouvir em silêncio
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        })
    }

    private fun cleanupRec() {
        speechRec?.let { try { it.destroy() } catch (_: Exception) {} }
        speechRec = null
    }

    private fun answer(question: String) {
        val key = prefs.getString("apiKey", "").orEmpty().trim()
        val mdl = prefs.getString("model", "gemini-flash-latest").orEmpty().trim().ifEmpty { "gemini-flash-latest" }
        if (key.isEmpty()) {
            speak("Você ouviu: $question. Cadastre a chave do Gemini no aplicativo para eu responder.") { resume() }
            return
        }
        status("Pensando: $question")
        thread(name = "jarvis-llm") {
            val reply = try { Gemini.ask(key, mdl, history.toList(), question) }
            catch (e: Exception) { null to (e.message ?: "erro") }
            main.post {
                if (reply is String) {
                    history.add(question to reply)
                    status("Jarvis: $reply")
                    speak(reply) { resume() }
                } else {
                    val msg = (reply as Pair<*, *>).second.toString()
                    status("Erro Gemini: $msg")
                    speak("Não consegui falar com o Gemini. $msg") { resume() }
                }
            }
        }
    }

    // ---------- encerramento ----------

    private fun shutdown() {
        running = false
        main.removeCallbacksAndMessages(null)
        cleanupRec()
        tts?.stop(); tts?.shutdown(); tts = null
        model?.close(); model = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_TEXT, "Parado"))
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
