package com.jarvis.clap

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Detecta DUAS palmas a partir de áudio PCM 16 kHz mono, em quadros de 20 ms (320 amostras).
 * Só lê números: não grava, não guarda e não envia áudio.
 *
 * Regras:
 *  - palma = subida brusca de energia acima do ruído de fundo E queda rápida (60 ms depois);
 *    fala é sustentada e não passa nesse teste;
 *  - duas palmas = 2ª entre 180 e 700 ms depois da 1ª;
 *  - se houver uma 3ª palma logo depois (aplauso), cancela.
 *
 * minLevel: energia mínima (0..1) para contar como palma. Menor = mais sensível.
 */
class ClapDetector(private val minLevel: Float = 0.05f) {
    companion object { const val FRAME = 320 }

    private var floor = 0.01f
    private var prev = 0f
    private var idx = 0
    private var pending = -1
    private var peak = 0f
    private var first = -1
    private var second = -1
    private var lockUntil = -1

    /** Processa 320 amostras a partir de [off]. Retorna true quando as duas palmas foram confirmadas. */
    fun process(s: ShortArray, off: Int): Boolean {
        var sum = 0.0
        for (k in off until off + FRAME) {
            val v = s[k] / 32768.0
            sum += v * v
        }
        val rms = sqrt(sum / FRAME).toFloat()
        val i = idx++
        var fire = false

        if (pending >= 0) {
            if (i - pending <= 2) peak = max(peak, rms)
            if (i - pending == 3) {
                if (rms < 0.4f * peak) onClap(pending, i) else lockUntil = i + 10
                pending = -1
            }
        } else if (i >= lockUntil && rms > max(floor * 5f, minLevel) && rms > prev * 2f) {
            pending = i
            peak = rms
        }

        if (pending < 0) {
            val a = if (rms < floor * 3f) 0.02f else 0.002f
            floor = min(0.05f, max(0.002f, floor + a * (rms - floor)))
        }

        if (second >= 0 && i >= second + 23 && i >= lockUntil) {
            second = -1
            first = -1
            lockUntil = i + 25
            fire = true
        }
        prev = rms
        return fire
    }

    private fun onClap(onset: Int, now: Int) {
        if (second >= 0) {            // 3ª palma durante a janela de confirmação = aplauso
            second = -1
            first = -1
            lockUntil = now + 75
            return
        }
        if (first >= 0 && onset - first in 9..35) {
            second = onset
            return
        }
        first = onset
        lockUntil = now + 5
    }
}
