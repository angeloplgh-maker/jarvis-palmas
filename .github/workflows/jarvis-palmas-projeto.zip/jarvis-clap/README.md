# Jarvis Palmas (experimental)

App Android que ouve e fala. Ativa com **duas palmas** ou **"Hey Jarvis"**, escuta o comando,
responde por voz usando o Gemini (chave gratuita). Só conversa: NÃO controla o celular.

Nada aqui foi compilado nem testado em aparelho pelo autor. A lógica das palmas só foi
testada com áudio sintético (Python). Calibre a sensibilidade no seu celular.

Build: aba Actions > "Build APK" > Run workflow > baixar o artefato `jarvis-palmas-debug-apk`.
